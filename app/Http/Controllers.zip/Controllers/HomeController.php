<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;


class HomeController extends Controller
{

    protected $CartCount;
    protected $loggedInUser;

    public function __construct()
    {
        // Construct
        //$user_ID = !empty(session()->get('user_id'))?session()->get('user_id'):'';
        //$this->CartCount = $this->updateproductdetails($user_ID); // Set the class property
        // dd($this->CartCount['action']);
    }

       // One api for show data in dashboard...G1
    public function oneAPIList(Request $request)
    {
        
        $title = "Quickart-category";
        $data_arr = array();
        $data_arr['title'] = "Farm Fresh Milk | Fresh Fruits and Vegetables | Quickart app";
        $data_arr['keywords'] = "";
        $data_arr['description'] = "Enjoy the finest organic & farm-fresh milk, Fresh fruits & vegetables with the QuicKart app. Our farm-fresh milk & fruits are sourced directly from local farms.";
        $data_arr['canonical'] = "";
        $data_arr['user_id'] = !empty(session()->get('user_id'))?session()->get('user_id'):'';  
        if(!empty(session()->get('user_id'))){
            $this->updateproductdetails($data_arr['user_id']); 
        }


        $nodeappUrl = env('NODE_APP_URL');
        $store_ID = env('STORE_ID');
        $user_ID = !empty(session()->get('user_id'))?session()->get('user_id'):'';
        $this->loggedInUser = !empty($request->session()->get('user_id')) ?
            $request->session()->get('user_id') : null;

        $oneAPIList = array();
        $errorMessage = null; // Initialize errorMessage to avoid undefined variable notice
        if ($request->has('utmSource')) {
            $utmSource = $request->query('utmSource');
            // Use or log it
            \Log::info('UTM Source: ' . $utmSource);
            try {
                    $client = new Client();
                    $response = $client->post($nodeappUrl . 'seo_source', [
                        'json' => [
                            'user_id' => $data_arr['user_id'],
                            "utm_source" => $request->query('utmSource'),
                            "utm_campaign" => $request->query('utmCampaign'),
                            "utm_network" => $request->query('utmNetwork'),
                            "utm_medium" => $request->query('utmMedium'),
                            "utm_keyword" => $request->query('utmKeyword'),
                            "placement" => $request->query('utmPlacement'),
                            "device_id" => "",
                            "fcm_token" => "",
                            "platform" => "web"
                        ]
                    ]);
                    // dd($response);
                    $statusCode = $response->getStatusCode();
                
                    $responseBody = json_decode($response->getBody()->getContents(), true);
                    if ($statusCode == 200 && isset($responseBody['status']) && $responseBody['status'] === "1") {
                         try {
                                $client = new Client();
                                $response = $client->post($nodeappUrl . 'oneapi', [
                                    'json' => [
                                        'store_id' => $store_ID,
                                        'user_id' => $user_ID,//!empty($this->loggedInUser) ? $this->loggedInUser : '',
                                        'is_subscription' => 1,
                                        'device_id' => ""
                                    ]
                                ]);

                                $statusCode = $response->getStatusCode();

                                if ($statusCode == 200) {
                                    // Decode the JSON response correctly
                                    $oneAPIList = json_decode($response->getBody()->getContents(), true);
                                } else {
                                    $errorMessage = env('ERRORMSG');
                                }
                            } catch (RequestException $e) {
                                $errorMessage = $e->getMessage();
                            } catch (\Exception $e) {
                                $errorMessage = $e->getMessage();
                            }
                   
                    } else {
                        $errorMessage = env('ERRORMSG');
                    }
                } catch (RequestException $e) {

                    $errorMessage = $e->getMessage();
                } catch (\Exception $e) {

                    $errorMessage = $e->getMessage();
                }
        } else {
            \Log::info('UTM Source not present');

            try {
                $client = new Client();
                $response = $client->post($nodeappUrl . 'oneapi', [
                    'json' => [
                        'store_id' => $store_ID,
                        'user_id' => $user_ID,//!empty($this->loggedInUser) ? $this->loggedInUser : '',
                        'is_subscription' => 1,
                        'device_id' => ""
                    ]
                ]);

                $statusCode = $response->getStatusCode();

                if ($statusCode == 200) {
                    // Decode the JSON response correctly
                    $oneAPIList = json_decode($response->getBody()->getContents(), true);
                } else {
                    $errorMessage = env('ERRORMSG');
                }
            } catch (RequestException $e) {
                $errorMessage = $e->getMessage();
            } catch (\Exception $e) {
                $errorMessage = $e->getMessage();
            }
        }
        return view('index', compact('title', 'data_arr', 'oneAPIList', 'errorMessage'))
            ->with('CartCount', $this->CartCount);
    }
    
    public function refund(){
        $data_arr = array();
        $data_arr['title'] = "Fresh Cow Milk in Dubai, UAE Home Delivery | Quickart";
        $data_arr['keywords'] = "";
        $data_arr['description'] = "QuicKart offers fresh cow milk in Dubai UAE home delivery straight from local farms.Our farm-fresh milk is delivered promptly to maintain its freshness & nutritional value.";
        $data_arr['canonical'] = "";
        $data_arr['user_id'] = !empty(session()->get('user_id'))?session()->get('user_id'):''; 
        if(!empty(session()->get('user_id'))){
            $this->updateproductdetails($data_arr['user_id']); 
        }

        return view('footer/return-refund', ['data_arr' => $data_arr]);
    }
    
    public function privacypolicy(){
         $data_arr = array();
        $data_arr['title'] = "Farm Fresh Dairy Products | Fresh Fruits and Vegetables | Quickart";
        $data_arr['keywords'] = "";
        $data_arr['description'] = "With QuicKart, you can buy Farm Fresh Dairy Products &amp; a selection of the finest organic fruits &amp; vegetables. Our privacy policy protects your personal information.";
        $data_arr['canonical'] = "";
        $data_arr['user_id'] = !empty(session()->get('user_id'))?session()->get('user_id'):''; 
        if(!empty(session()->get('user_id'))){
            $this->updateproductdetails($data_arr['user_id']); 
        }

        return view('footer/privacy-policy', ['data_arr' => $data_arr]);
    }
    
      // Seo api call index page in dashboard...G1
    public function seoCallForIndex(Request $request)
    {
        $title = "Quickart-category";
        $data_arr = array();
        $data_arr['title'] = "Farm Fresh Milk | Fresh Fruits and Vegetables | Quickart app";
        $data_arr['keywords'] = "";
        $data_arr['description'] = "Enjoy the finest organic & farm-fresh milk, Fresh fruits & vegetables with the QuicKart app. Our farm-fresh milk & fruits are sourced directly from local farms.";
        $data_arr['canonical'] = "";
        $data_arr['user_id'] = !empty(session()->get('user_id'))?session()->get('user_id'):'';  
       
        $nodeappUrl = env('NODE_APP_URL');
        $store_ID = env('STORE_ID');
        $user_ID = !empty(session()->get('user_id'))?session()->get('user_id'):'';
        $this->loggedInUser = !empty($request->session()->get('user_id')) ?
            $request->session()->get('user_id') : null;

        $oneAPIList = array();
        $errorMessage = null; // Initialize errorMessage to avoid undefined variable notice
        if ($request->has('utmSource')) {
            $utmSource = $request->query('utmSource');
            // Use or log it
            \Log::info('UTM Source: ' . $utmSource);
            try {
                    $client = new Client();
                    $response = $client->post($nodeappUrl . 'seo_source', [
                        'json' => [
                            'user_id' => $data_arr['user_id'],
                            "utm_source" => $request->query('utmSource'),
                            "utm_campaign" => $request->query('utmCampaign'),
                            "utm_network" => $request->query('utmNetwork'),
                            "utm_medium" => $request->query('utmMedium'),
                            "utm_keyword" => $request->query('utmKeyword'),
                            "placement" => $request->query('utmPlacement'),
                            "device_id" => "",
                            "fcm_token" => "",
                            "platform" => "web"
                        ]
                    ]);
                    // dd($response);
                    $statusCode = $response->getStatusCode();
                
                    $responseBody = json_decode($response->getBody()->getContents(), true);
                    if ($statusCode == 200 && isset($responseBody['status']) && $responseBody['status'] === "1") {
                    } else {
                        $errorMessage = env('ERRORMSG');
                    }
                } catch (RequestException $e) {

                    $errorMessage = $e->getMessage();
                } catch (\Exception $e) {

                    $errorMessage = $e->getMessage();
                }
        } else {
            \Log::info('UTM Source not present');

        }
         return redirect()->to('/'); 
    }
}